# Esercizio 12 – Cinema *(difficoltà: ★★☆☆☆)*

Un cinema proietta film, ognuno con codice, titolo, durata e anno, diretto da un solo regista (codice, nome, cognome, nazionalità) che ne può dirigere molti. Le sale hanno numero e capienza. Ogni film può essere proiettato in più sale e ogni sala può ospitare più film. Per ogni proiezione si registrano data e ora di inizio.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
