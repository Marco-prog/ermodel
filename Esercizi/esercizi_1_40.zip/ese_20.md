# Esercizio 20 – Persone con generalizzazione *(difficoltà: ★★★★☆)*

Una scuola gestisce persone (codice fiscale, nome, cognome, data di nascita), che possono essere studenti (matricola, classe) o docenti (codice, materia, anni di servizio). Ogni persona è o studente o docente, mai entrambi. Le classi (anno, sezione, indirizzo) hanno più studenti, mentre ogni studente appartiene a una sola classe. Ogni docente insegna in più classi e in ogni classe insegnano più docenti.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
