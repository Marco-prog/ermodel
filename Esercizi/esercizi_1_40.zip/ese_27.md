# Esercizio 27 – Piattaforma musicale *(difficoltà: ★★★★☆)*

Una piattaforma musicale gestisce artisti (codice, nome d'arte, nazione), album (codice, titolo, anno), brani (codice, titolo, durata) e utenti (username, email, data di iscrizione). Ogni album è pubblicato da un artista e contiene più brani, ciascuno con il numero di traccia nell'album. Un brano appartiene a un solo album. Un utente ascolta più brani e ogni brano è ascoltato da più utenti; per ogni ascolto si memorizzano data e ora.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
