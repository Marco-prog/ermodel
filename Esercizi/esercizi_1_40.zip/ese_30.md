# Esercizio 30 – Eventi *(difficoltà: ★★★★★)*

Un'agenzia organizza eventi (codice, nome, data, tipologia) che si svolgono in luoghi (codice, nome, indirizzo, capienza). Un luogo ospita più eventi, ma un evento si svolge in un solo luogo. Agli eventi partecipano persone (codice fiscale, nome, cognome, email), che possono essere relatori o semplici partecipanti; i relatori hanno in più un titolo e un ente di appartenenza. Gli sponsor (partita IVA, ragione sociale) finanziano più eventi e ogni evento ha più sponsor, con l'importo versato da ciascuno. Un evento è identificato dall'insieme delle informazioni di luogo e data, ma si preferisce usare un codice.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
