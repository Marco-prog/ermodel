# Esercizio 4 – Medici e pazienti *(difficoltà: ★★☆☆☆)*

Un'ASL registra i medici di base, con matricola, nome, cognome e ambulatorio, e i pazienti, con tessera sanitaria, nome, cognome, indirizzo e data di nascita. Ogni paziente è assegnato a un solo medico, che può averne molti. Si vuole memorizzare la data di assegnazione.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
