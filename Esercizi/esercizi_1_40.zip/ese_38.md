# Esercizio 38 – Agenzia viaggi *(difficoltà: ★★★★★)*

Un'agenzia di viaggi propone viaggi (codice, nome, durata, prezzo base) composti da più tappe in ordine, ciascuna in una destinazione (codice, nome, nazione). Ogni tappa ha un numero d'ordine e un numero di notti. In ogni destinazione l'agenzia si appoggia a più hotel (codice, nome, stelle) e a più guide (codice, nome, cognome, lingue parlate). I clienti (documento, nome, cognome, email) prenotano le partenze di un viaggio, ciascuna con una data di partenza e un numero massimo di posti. Per ogni prenotazione si registrano il numero di partecipanti e l'acconto versato. A ogni partenza si assegna una guida per tappa.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
