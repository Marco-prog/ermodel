# Esercizio 14 – Corsi e docenti *(difficoltà: ★★★☆☆)*

Un centro di formazione offre corsi (codice, titolo, ore), tenuti da docenti (codice fiscale, nome, cognome, titolo di studio) e frequentati da iscritti (tessera, nome, cognome, email). Ogni corso è tenuto da un solo docente, che può tenere più corsi. Gli iscritti si iscrivono a più corsi; per ogni iscrizione si registrano data e stato del pagamento.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
