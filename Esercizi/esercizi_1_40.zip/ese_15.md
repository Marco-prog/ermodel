# Esercizio 15 – Hotel *(difficoltà: ★★★☆☆)*

Una catena alberghiera ha più hotel (codice, nome, città, categoria in stelle). Ogni hotel ha più camere identificate da un numero progressivo all'interno dell'hotel, con tipologia e prezzo a notte. I clienti (documento, nome, cognome, nazionalità) prenotano le camere. Per ogni prenotazione si registrano data di arrivo e di partenza. Una stessa camera può essere prenotata più volte in periodi diversi.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
