# Esercizio 40 – Piattaforma di e-learning *(difficoltà: ★★★★★)*

Una piattaforma di formazione online ha utenti (username, email, data di registrazione), che sono studenti (livello, crediti accumulati) o docenti (biografia, curriculum). Un utente può essere entrambi. I corsi (codice, titolo, descrizione, durata) sono creati da uno o più docenti e sono composti da lezioni, che si identificano tramite un numero progressivo all'interno del corso e hanno titolo, durata e tipo di contenuto. Un corso può avere come prerequisiti altri corsi. Gli studenti si iscrivono ai corsi con data e stato di avanzamento, e per ogni lezione completata si registrano data e punteggio. Al termine di un corso lo studente può ottenere un certificato (codice, data di rilascio), relativo a una specifica iscrizione. Le categorie (codice, nome) raggruppano i corsi e un corso può appartenere a più categorie.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
