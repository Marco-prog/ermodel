# Esercizio 5 – Auto e proprietari *(difficoltà: ★★☆☆☆)*

Si vuole gestire il parco auto di una città. Di ogni auto si conoscono targa, marca, modello e anno di immatricolazione. Di ogni proprietario si conoscono codice fiscale, nome, cognome e residenza. Un'auto ha un solo proprietario, ma una persona può possedere più auto. Alcune persone registrate possono non possedere ancora nessuna auto.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
