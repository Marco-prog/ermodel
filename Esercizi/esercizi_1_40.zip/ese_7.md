# Esercizio 7 – Studenti e corsi extracurricolari *(difficoltà: ★★☆☆☆)*

Una scuola organizza corsi extracurricolari, ciascuno con codice, titolo e durata in ore. Gli studenti, identificati da matricola e descritti da nome e cognome, possono iscriversi a più corsi e ogni corso accoglie più studenti.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
