# Esercizio 3 – Squadre e giocatori *(difficoltà: ★☆☆☆☆)*

Una società sportiva gestisce più squadre, di ciascuna delle quali si conoscono nome, categoria e colori sociali. Ogni giocatore ha un numero di tessera, nome, cognome, ruolo e data di nascita, e appartiene a una sola squadra.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
