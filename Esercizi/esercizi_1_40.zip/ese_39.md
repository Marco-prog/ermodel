# Esercizio 39 – Produzione industriale *(difficoltà: ★★★★★)*

Un'azienda manifatturiera produce prodotti (codice, nome, prezzo di vendita) assemblati da componenti (codice, descrizione, costo). Alcuni componenti sono a loro volta composti da altri componenti. Si vuole indicare, per ogni composizione, la quantità necessaria. I componenti sono forniti da fornitori (partita IVA, ragione sociale), con prezzo e tempo di consegna. Sono presenti più magazzini (codice, città, capacità) in cui sono stoccati i componenti, con la giacenza e la scorta minima. Gli ordini di produzione (numero, data, quantità, stato) riguardano un prodotto e sono evasi in un magazzino.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
