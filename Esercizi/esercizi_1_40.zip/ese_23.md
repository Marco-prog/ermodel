# Esercizio 23 – Voli aerei *(difficoltà: ★★★★☆)*

Una compagnia aerea possiede aerei (matricola, modello, posti), effettua voli (codice, data, ora di partenza, ora di arrivo) e opera su aeroporti (sigla, nome, città, nazione). Ogni volo è eseguito da un solo aereo e collega due aeroporti diversi: quello di partenza e quello di arrivo. I passeggeri (documento, nome, cognome) prenotano i voli; per ogni prenotazione si registrano il posto assegnato e la classe di viaggio.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
