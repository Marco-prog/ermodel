# Esercizio 36 – Organigramma aziendale *(difficoltà: ★★★★★)*

Un'azienda ha sedi (codice, città, indirizzo), dipartimenti (codice, nome), dipendenti (matricola, nome, cognome, stipendio), progetti (codice, titolo, budget) e competenze (codice, descrizione). Ogni dipartimento ha sede in una sola sede (cardinalità da stabilire) e ogni dipendente lavora in un solo dipartimento. Ogni dipendente ha un solo responsabile, che è a sua volta un dipendente, mentre un dipendente può essere responsabile di più persone. I dipendenti possiedono più competenze, con un livello da 1 a 5. Ai progetti lavorano più dipendenti, con ruolo e ore. Per ogni progetto si indica anche quali competenze sono richieste.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
