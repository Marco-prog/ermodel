# Esercizio 10 – Edifici e aule *(difficoltà: ★★★☆☆)*

Un ente gestisce gli edifici scolastici di una provincia, ciascuno con codice, nome e indirizzo. Ogni edificio contiene più aule. Ogni aula ha un numero (progressivo all'interno dell'edificio, quindi non univoco in assoluto), un piano e una capienza. Un'aula non esiste senza l'edificio che la contiene.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
