# Esercizio 21 – Ristorante *(difficoltà: ★★★☆☆)*

Un ristorante gestisce tavoli (numero, posti, sala), camerieri (matricola, nome, cognome), piatti (codice, nome, prezzo, categoria) e comande (numero, data, ora). Ogni comanda è relativa a un solo tavolo ed è presa da un solo cameriere. Una comanda contiene più piatti, ciascuno con la quantità ordinata, e un piatto può comparire in più comande.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
