# Esercizio 29 – Visite mediche *(difficoltà: ★★★★☆)*

Un poliambulatorio ha specializzazioni (codice, nome), medici (matricola, nome, cognome) e pazienti (tessera sanitaria, nome, cognome). Ogni medico ha una sola specializzazione, che è posseduta da più medici. Le visite, identificate da codice, sono eseguite da un medico su un paziente in una certa data e ora. Per ogni visita si registrano diagnosi e costo. Si vuole inoltre sapere quali visite sono di controllo rispetto a una visita precedente dello stesso paziente.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
