# Esercizio 16 – Palestra *(difficoltà: ★★★☆☆)*

Una palestra gestisce soci (tessera, nome, cognome, data di iscrizione, scadenza abbonamento), istruttori (codice, nome, cognome, specializzazione) e corsi (codice, nome, livello, giorno e ora settimanale). Ogni corso è condotto da un solo istruttore. I soci possono frequentare più corsi e ogni corso ha più soci. Un istruttore può condurre più corsi.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
