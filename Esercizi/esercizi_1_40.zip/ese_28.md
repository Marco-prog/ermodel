# Esercizio 28 – Clienti e dipendenti *(difficoltà: ★★★★☆)*

Un'azienda gestisce persone (codice fiscale, nome, cognome, telefono) che possono essere clienti (codice cliente, tipo di pagamento) o dipendenti (matricola, data di assunzione, stipendio). Una persona può essere sia cliente sia dipendente. Ogni dipendente lavora in una filiale (codice, città, indirizzo). Le filiali emettono fatture (numero, data, importo) a favore dei clienti; ogni fattura è emessa da una sola filiale a un solo cliente.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
