# Esercizio 2 – Dipendenti e reparti *(difficoltà: ★☆☆☆☆)*

Un'azienda è divisa in reparti, ciascuno con un codice, un nome e un numero di telefono interno. Ogni dipendente, descritto da codice fiscale, nome, cognome e stipendio, lavora in un solo reparto. In un reparto lavorano più dipendenti.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
