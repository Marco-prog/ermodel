# Esercizio 25 – Prestiti bibliotecari *(difficoltà: ★★★★☆)*

Una biblioteca distingue il titolo (ISBN, titolo, anno, autore principale) dalle singole copie fisiche (numero di inventario, scaffale, stato di conservazione). Un titolo ha più copie, ma ogni copia appartiene a un solo titolo. Gli utenti (tessera, nome, cognome, email) prendono in prestito le copie. Per ogni prestito si registrano data di prestito e data di restituzione. Una copia può essere prestata più volte nel tempo. Gli autori (codice, nome, cognome) hanno scritto più titoli e ogni titolo può avere più autori.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
