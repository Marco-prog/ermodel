# Esercizio 22 – Università *(difficoltà: ★★★☆☆)*

Un'università è organizzata in facoltà (codice, nome, preside), ciascuna con più corsi di laurea (codice, nome, durata in anni). Un corso di laurea appartiene a una sola facoltà. Gli studenti (matricola, nome, cognome) sono iscritti a un solo corso di laurea, con anno di immatricolazione. Gli insegnamenti (codice, nome, crediti) appartengono a un corso di laurea. Gli studenti sostengono gli esami degli insegnamenti, con data e voto.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
