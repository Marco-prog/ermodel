# Esercizio 11 – Biblioteca *(difficoltà: ★★☆☆☆)*

Una biblioteca gestisce libri, autori e case editrici. Del libro si conoscono ISBN, titolo e anno; dell'autore codice, nome e cognome; della casa editrice nome, città e sito web. Un libro è pubblicato da una sola casa editrice, che ne pubblica molti. Un libro può avere più autori e un autore più libri.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
