# Esercizio 1 – Alunni e classe *(difficoltà: ★☆☆☆☆)*

Si vuole rappresentare la realtà degli alunni di una scuola che si trovano in una classe. Di ogni classe si conoscono anno, sezione e indirizzo; di ogni alunno matricola, nome, cognome e data di nascita. Un alunno frequenta una sola classe, mentre in una classe ci sono più alunni.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
