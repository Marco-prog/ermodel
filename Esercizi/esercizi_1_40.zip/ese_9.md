# Esercizio 9 – Studenti ed esami *(difficoltà: ★★★☆☆)*

L'università gestisce gli studenti (matricola, nome, cognome, corso di laurea) e gli esami (codice, nome, crediti). Uno studente può sostenere lo stesso esame più volte, in date diverse. Per ogni tentativo si registrano la data e il voto (o l'eventuale ritiro).

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
