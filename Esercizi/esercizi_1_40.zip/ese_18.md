# Esercizio 18 – Azienda e progetti *(difficoltà: ★★★★☆)*

In un'azienda i dipendenti (matricola, nome, cognome, qualifica) appartengono a un solo dipartimento (codice, nome, sede). I dipendenti lavorano a più progetti (codice, titolo, budget, data di inizio) e ogni progetto coinvolge più dipendenti. Per ogni partecipazione si registrano le ore settimanali dedicate e il ruolo ricoperto. Ogni dipartimento gestisce più progetti, ma ogni progetto è gestito da un solo dipartimento.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
