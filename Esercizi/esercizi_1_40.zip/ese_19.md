# Esercizio 19 – Rete ferroviaria *(difficoltà: ★★★★☆)*

Una compagnia ferroviaria gestisce linee (codice, nome), treni (numero, tipo, numero di posti) e stazioni (codice, nome, città). Ogni treno percorre una sola linea, che è percorsa da più treni. Un treno si ferma in più stazioni, e in una stazione si fermano più treni. Per ogni fermata si registrano orario di arrivo, orario di partenza e binario.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
