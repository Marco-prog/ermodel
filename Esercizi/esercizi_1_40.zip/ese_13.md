# Esercizio 13 – Negozio online *(difficoltà: ★★★☆☆)*

Un negozio online gestisce clienti (codice, nome, cognome, email, indirizzo), ordini (numero, data, stato) e prodotti (codice, descrizione, prezzo di listino). Un cliente effettua più ordini, ma ogni ordine è di un solo cliente. Un ordine contiene più prodotti e un prodotto può comparire in più ordini. Per ogni prodotto in un ordine si registrano quantità e prezzo applicato.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
