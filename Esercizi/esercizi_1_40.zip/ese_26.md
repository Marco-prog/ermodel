# Esercizio 26 – Farmacia *(difficoltà: ★★★★☆)*

Una farmacia gestisce farmaci (codice AIC, nome commerciale, prezzo, forma farmaceutica) e principi attivi (codice, nome). Ogni farmaco contiene più principi attivi, ciascuno con un dosaggio in mg, e un principio attivo è presente in più farmaci. I medici (numero albo, nome, cognome) emettono ricette (numero, data) per i pazienti (tessera sanitaria, nome, cognome). Ogni ricetta è emessa da un medico per un paziente e può prescrivere più farmaci, ciascuno con posologia e numero di confezioni.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
