# Esercizio 31 – E-commerce completo *(difficoltà: ★★★☆☆)*

Un negozio online gestisce clienti (codice, nome, cognome, email), ordini (numero, data, stato), prodotti (codice, nome, prezzo), categorie (codice, nome) e fornitori (partita IVA, ragione sociale, città). Ogni cliente effettua più ordini. Un ordine contiene più prodotti con quantità e prezzo applicato. Ogni prodotto appartiene a una sola categoria e può essere fornito da più fornitori, ciascuno con un proprio prezzo di acquisto e un tempo di consegna.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
