# Esercizio 32 – Scuola e orario *(difficoltà: ★★★★☆)*

Una scuola gestisce classi (anno, sezione), studenti (matricola, nome, cognome), docenti (codice, nome, cognome), materie (codice, nome, ore annuali) e aule (numero, piano, capienza). Ogni studente appartiene a una classe. Un docente può insegnare più materie. Nell'orario settimanale una classe, in un dato giorno e in una data ora, segue una materia con un docente in un'aula. Una classe non può avere due lezioni contemporanee, e lo stesso vale per un docente e per un'aula.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
