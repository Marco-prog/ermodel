# Esercizio 6 – Passaporti e persone *(difficoltà: ★★☆☆☆)*

Un ufficio anagrafe registra le persone (codice fiscale, nome, cognome, luogo e data di nascita) e i passaporti (numero, data di rilascio, data di scadenza). Ogni passaporto appartiene a una sola persona e ogni persona può avere al massimo un passaporto valido.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
