# Esercizio 35 – Campionato e arbitri *(difficoltà: ★★★★☆)*

Un campionato comprende squadre (codice, nome, anno di fondazione), giocatori (codice, nome, cognome, ruolo), stadi (codice, nome, città, capienza), arbitri (tessera, nome, cognome, sezione) e partite (codice, data, giornata). Ogni squadra ha uno stadio di casa, che può essere condiviso con un'altra squadra. Ogni giocatore appartiene a una squadra, ma può cambiare squadra nel tempo, e si vuole conservare lo storico con date di inizio e fine. Ogni partita è giocata da due squadre in uno stadio, ed è diretta da un arbitro designato. Per ogni partita si registrano i gol di ogni squadra e i marcatori, con il minuto.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
