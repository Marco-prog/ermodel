# Esercizio 24 – Noleggio auto *(difficoltà: ★★★★☆)*

Un'agenzia di noleggio ha più sedi (codice, città, indirizzo). Ogni auto (targa, modello, categoria, tariffa giornaliera) è assegnata a una sede di appartenenza. I clienti (patente, nome, cognome, telefono) noleggiano le auto. Di ogni noleggio si registrano data di inizio, data di fine prevista, data di restituzione effettiva e la sede di ritiro e di riconsegna, che può essere diversa.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
