# Esercizio 8 – Libri e autori *(difficoltà: ★★★☆☆)*

Una libreria cataloga i libri (ISBN, titolo, anno di pubblicazione, prezzo) e gli autori (codice, nome, cognome, nazionalità). Un libro può avere più autori e un autore può aver scritto più libri. Per ogni coppia libro-autore si vuole sapere se l'autore è curatore o autore principale.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
