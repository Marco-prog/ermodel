# Esercizio 37 – Biblioteca universitaria *(difficoltà: ★★★★★)*

Una biblioteca universitaria gestisce utenti (codice, nome, cognome, email), che sono studenti (matricola, corso di laurea) o docenti (dipartimento, ufficio). Ogni utente è di una sola tipologia. Gestisce anche titoli (ISBN, titolo, anno), copie (numero di inventario, collocazione), prestiti e sedi (codice, nome, indirizzo). Ogni titolo ha più copie e ogni copia si trova in una sola sede. I prestiti riguardano una copia e un utente, con data di inizio, scadenza e restituzione. Gli studenti possono avere al massimo tre prestiti contemporanei, i docenti dieci. Un utente può prenotare un titolo se tutte le copie sono in prestito, con data della prenotazione.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
