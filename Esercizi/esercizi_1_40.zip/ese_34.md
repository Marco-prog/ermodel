# Esercizio 34 – Ospedale *(difficoltà: ★★★★☆)*

Un ospedale ha reparti (codice, nome, piano), medici (matricola, nome, cognome, specializzazione), pazienti (tessera sanitaria, nome, cognome, data di nascita), ricoveri e farmaci (codice, nome, principio attivo). Ogni medico appartiene a un solo reparto. Un ricovero è relativo a un paziente e a un reparto, ha data di ingresso, data di dimissione e diagnosi, ed è seguito da più medici. Durante un ricovero si somministrano farmaci, con dose, data e ora. Un paziente può avere più ricoveri.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
