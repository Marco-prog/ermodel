# Esercizio 17 – Campionato di calcio *(difficoltà: ★★★★☆)*

Un campionato è formato da squadre (codice, nome, città), giocatori (codice, nome, cognome, ruolo) e partite (codice, data, giornata). Ogni giocatore appartiene a una sola squadra. Ogni partita è disputata da due squadre diverse, una in casa e una in trasferta; per ogni squadra si memorizzano i gol segnati.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
