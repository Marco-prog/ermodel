# Esercizio 33 – Hotel e servizi *(difficoltà: ★★★★☆)*

Una catena alberghiera ha hotel (codice, nome, città, stelle) con camere identificate da un numero all'interno dell'hotel (tipologia, prezzo). I clienti (documento, nome, cognome, nazionalità) effettuano prenotazioni (codice, data di arrivo, data di partenza) relative a una o più camere. Gli hotel offrono servizi (codice, nome, descrizione) come spa, ristorante, navetta, con un prezzo che può variare da hotel a hotel. Durante un soggiorno il cliente può richiedere servizi, con data e quantità.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni);
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
