# Esercizio 45 – Forniture e collaudi *(difficoltà: ★★★★☆)*

Un'azienda manifatturiera gestisce i fornitori (partita IVA, ragione sociale, città), i componenti (codice, descrizione, costo) e le commesse (numero, cliente, data di consegna). Un fornitore fornisce componenti per una commessa: la stessa terna fornitore-componente-commessa è unica e ha una quantità e un prezzo unitario. Ogni fornitura può essere sottoposta a più collaudi (codice, data, esito, note facoltative); ogni collaudo riguarda una sola fornitura.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni), individuando e motivando le aggregazioni necessarie;
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
