# Esercizio 46 – Scuola di nuoto *(difficoltà: ★★★★☆)*

Una scuola di nuoto gestisce gli allievi (tessera, nome, cognome, data di nascita) e i corsi (codice, livello, giorno, ora). Un allievo si iscrive a più corsi e a un corso si iscrivono più allievi, con una data di iscrizione. Ogni iscrizione viene pagata a rate: di ogni pagamento (codice, data, importo) si vuole conoscere l'iscrizione a cui si riferisce. Al termine di un'iscrizione l'allievo può ricevere un attestato (numero, data, livello raggiunto); per ogni iscrizione c'è al massimo un attestato e ogni attestato si riferisce a una sola iscrizione.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni), individuando e motivando le aggregazioni necessarie;
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
