# Esercizio 47 – Volontari, eventi e turni *(difficoltà: ★★★★★)*

Un'associazione gestisce le persone (codice fiscale, nome, cognome, telefono), che sono volontari (tessera, data di iscrizione) oppure professionisti retribuiti (partita IVA, ordine professionale); nessuna persona è entrambe le cose. Gli eventi (codice, nome, data, luogo) sono organizzati con il supporto dei soli volontari: un volontario può essere assegnato a più eventi e un evento ha più volontari, ciascuno con un ruolo. Per ogni assegnazione si definiscono più turni (numero, ora di inizio, ora di fine) e al massimo un rimborso spese (codice, importo, data di pagamento facoltativa), che si riferisce a una sola assegnazione.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni), individuando e motivando le aggregazioni necessarie;
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
