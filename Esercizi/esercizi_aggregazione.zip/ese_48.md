# Esercizio 48 – Ricoveri, terapie ed effetti collaterali *(difficoltà: ★★★★★)*

Un ospedale gestisce i pazienti (tessera sanitaria, nome, cognome, data di nascita) e i reparti (codice, nome, piano). Un paziente può essere ricoverato più volte nello stesso reparto, in date diverse; di ogni ricovero si registrano data di ingresso, data di dimissione (facoltativa) e diagnosi. Durante un ricovero si prescrivono più terapie (codice, data di inizio, durata in giorni). Ogni terapia comprende più farmaci (codice, nome, principio attivo), ciascuno con dose e frequenza, e un farmaco può comparire in più terapie. Per ogni farmaco di una terapia si possono registrare più effetti collaterali (codice, data, descrizione, gravità).

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni), individuando e motivando le aggregazioni necessarie;
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
