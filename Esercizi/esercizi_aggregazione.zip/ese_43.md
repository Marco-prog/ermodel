# Esercizio 43 – Spettacoli e pagamenti *(difficoltà: ★★★☆☆)*

Un teatro gestisce gli spettatori (codice fiscale, nome, cognome, email) e gli spettacoli (codice, titolo, data, ora). Uno spettatore può prenotare più spettacoli e uno spettacolo è prenotato da più spettatori; per ogni prenotazione si registra il numero di posti. Una prenotazione può essere pagata in più rate: di ogni pagamento (codice, data, importo, metodo) si deve sapere a quale prenotazione si riferisce.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni), individuando e motivando le aggregazioni necessarie;
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
