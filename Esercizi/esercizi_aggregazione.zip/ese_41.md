# Esercizio 41 – Certificati di corso *(difficoltà: ★★★☆☆)*

Un centro di formazione gestisce gli studenti (matricola, nome, cognome, email) e i corsi (codice, titolo, ore). Uno studente può iscriversi a più corsi e ogni corso ha più iscritti; per ogni iscrizione si registra la data. Al termine di una specifica iscrizione, se superata, lo studente ottiene un certificato (numero, data di rilascio, voto finale). Per ogni iscrizione esiste al massimo un certificato e ogni certificato si riferisce a una sola iscrizione.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni), individuando e motivando le aggregazioni necessarie;
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
