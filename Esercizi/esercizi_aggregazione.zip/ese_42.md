# Esercizio 42 – Valutazioni dei progetti *(difficoltà: ★★★☆☆)*

Un'azienda gestisce i dipendenti (matricola, nome, cognome, qualifica) e i progetti (codice, titolo, budget). Un dipendente partecipa a più progetti e a un progetto partecipano più dipendenti, con un ruolo. Durante la partecipazione di un dipendente a un progetto il responsabile può registrare più valutazioni periodiche (numero, data, punteggio e un commento facoltativo). Ogni valutazione si riferisce a una sola partecipazione.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni), individuando e motivando le aggregazioni necessarie;
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
