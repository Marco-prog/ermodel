# Esercizio 44 – Docenti, corsi e lezioni *(difficoltà: ★★★★☆)*

Un'università gestisce i docenti (codice fiscale, nome, cognome), i corsi (codice, titolo, crediti) e le aule (numero, piano, capienza). Un docente può tenere più corsi e un corso può essere tenuto da più docenti; l'incarico è assegnato per un anno accademico, per cui lo stesso docente può tenere lo stesso corso in anni diversi, con un certo numero di ore assegnate. Nell'ambito di ciascun incarico si svolgono più lezioni (codice, data, ora di inizio, durata, argomento). Ogni lezione appartiene a un solo incarico e si svolge in una sola aula.

**Si richiede di:**
1. individuare le entità e gli attributi, indicando gli identificatori;
2. definire le relazioni e le relative cardinalità (con eventuali attributi delle relazioni), individuando e motivando le aggregazioni necessarie;
3. disegnare il diagramma ER;
4. ricavare il modello logico (schema relazionale), indicando chiavi primarie ed esterne.
